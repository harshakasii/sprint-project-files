package com.coursemanagement.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.coursemanagement.app.entity.Account;
import com.coursemanagement.app.service.AccountService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping("/register")
    public ResponseEntity<String> register(@Valid @RequestBody Account account) {
        return ResponseEntity.ok(accountService.registerAccount(account));
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestParam String email,
                                        @RequestParam String password,
                                        @RequestParam Account.Role role) {
        return ResponseEntity.ok(accountService.loginAccount(email, password, role));
    }
}