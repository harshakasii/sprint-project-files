package com.coursemanagement.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coursemanagement.app.entity.Account;
import com.coursemanagement.app.entity.Instructor;
import com.coursemanagement.app.entity.Student;
import com.coursemanagement.app.repository.AccountRepository;
import com.coursemanagement.app.repository.InstructorRepository;
import com.coursemanagement.app.repository.StudentRepository;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private InstructorRepository instructorRepository;

    @Autowired
    private StudentRepository studentRepository;

    public String registerAccount(Account account) {
        // Save account details to the account table
        accountRepository.save(account);

        // Add to instructor or student table based on the role
        if (account.getRole() == Account.Role.INSTRUCTOR) {
            Instructor instructor = new Instructor();
            instructor.setId(account.getId());
            instructor.setEmail(account.getEmail());
            instructor.setName(account.getName());
            instructor.setPassword(account.getPassword());
            instructorRepository.save(instructor);
            return "Instructor registered successfully";
        } else if (account.getRole() == Account.Role.STUDENT) {
            Student student = new Student();
            student.setId(account.getId());
            student.setEmail(account.getEmail());
            student.setName(account.getName());
            student.setPassword(account.getPassword());
            studentRepository.save(student);
            return "Student registered successfully";
        }

        return "Account registered successfully";
    }

    public String loginAccount(String email, String password, Account.Role role) {
        Account account = accountRepository.findByEmailAndPasswordAndRole(email, password, role)
                .orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));

        // Call the corresponding service based on the role
        if (role == Account.Role.ADMIN) {
            return "Redirecting to admin service...";
        } else if (role == Account.Role.INSTRUCTOR) {
            return "Redirecting to instructor service...";
        } else if (role == Account.Role.STUDENT) {
            return "Redirecting to student service...";
        }

        return "Invalid role";
    }
}
